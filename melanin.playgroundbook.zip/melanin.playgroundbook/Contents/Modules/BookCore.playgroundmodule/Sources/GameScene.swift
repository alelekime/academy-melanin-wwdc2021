import SpriteKit
import PlaygroundSupport

public class GameScene: SKScene {

    private var label : SKLabelNode!
    private var spinnyNode : SKShapeNode!

    
    let fullRainbow = SKSpriteNode(imageNamed: "fullRainbow")
    let melanin = SKSpriteNode(imageNamed: "melanin")
    let nextPage = SKSpriteNode(imageNamed: "nextPage")
    
    let fadeIn = SKAction.fadeIn(withDuration: 2)
    let wait = SKAction.wait(forDuration: 2)

    override public func didMove(to view: SKView) {
        
        
        fullRainbow.setScale(0.3)
        melanin.setScale(0.7)
        nextPage.setScale(0.5)
        fullRainbow.position = CGPoint(x: self.size.width/2, y: self.size.height/2 + 90)
        melanin.position = CGPoint(x: self.size.width/2 + 5, y: self.size.height/2 - 80)
        nextPage.position = CGPoint(x: self.size.width/2 + 300, y: self.size.height/2 - 300)
        
       
        fullRainbow.run(.sequence([wait,fadeIn]))
        melanin.run(.sequence([wait, wait, fadeIn]))
        
        
        addChild(fullRainbow)
        addChild(melanin)
        addChild(nextPage)
        
        
        
        self.backgroundColor = UIColor(red: 0.91, green: 0.76, blue: 0.61, alpha: 1.00)
    }

    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }

    func touchDown(atPoint pos : CGPoint) {
        if nextPage.contains(pos){
            PlaygroundPage.current.navigateTo(page: .next)
        }
    }

    func touchMoved(toPoint pos : CGPoint) {
//        guard let n = self.spinnyNode.copy() as? SKShapeNode else { return }
//
//        n.position = pos
//        n.strokeColor = SKColor.yellow
//        addChild(n)
    }

    func touchUp(atPoint pos : CGPoint) {
//        guard let n = spinnyNode.copy() as? SKShapeNode else { return }
//
//        n.position = pos
//        n.strokeColor = SKColor.red
//        addChild(n)
    }

    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}

