//
//  Rain.swift
//  BookCore
//
//  Created by Alessandra Souza da Silva on 15/04/21.
//
import SpriteKit
import PlaygroundSupport
import Foundation
public class Colors: SKScene {
    
    
    let chapterII = SKSpriteNode(imageNamed: "chapter2")
    let nextPage = SKSpriteNode(imageNamed: "nextPage")
    let nextPage1 = SKSpriteNode(imageNamed: "nextChapter")
    
    let brown = SKSpriteNode(imageNamed: "brown")
    let rainbow = SKSpriteNode(imageNamed: "rainbow")
    let fullRainbow = SKSpriteNode(imageNamed: "fullRainbow")
    let blueButton = SKSpriteNode(imageNamed: "blueButton")
    let redButton = SKSpriteNode(imageNamed: "redButton")
    let brownButton = SKSpriteNode(imageNamed: "brownButton")
    
    let quote1 = SKLabelNode(fontNamed: "Palatino")
    let quote2 = SKLabelNode(fontNamed: "Palatino")
    let quote3 = SKLabelNode(fontNamed: "Palatino")
    let quote4 = SKLabelNode(fontNamed: "Palatino")
    
    var brownCont = 0
    var blueCont = 0
    var redCont = 0
    
    let fadeOutWait = SKAction.wait(forDuration: 4)
    let fadeOut = SKAction.fadeOut(withDuration: 1)
    let fadeIn = SKAction.fadeIn(withDuration: 2)
    let backgroundScale = SKAction.scale(by: 0.5, duration: 1)
    let backgroundMove = SKAction.moveBy(x: 0, y: 10, duration: 1)
    let backgroundFade = SKAction.fadeAlpha(to: 0.23, duration: 0.7)
    let fadeInWait = SKAction.wait(forDuration: 2)
    let waitText = SKAction.wait(forDuration: 2)
    
    override public func didMove(to view: SKView) {
        
        
        redButton.setScale(0.7)
        redButton.position = CGPoint(x: self.size.width/2, y: self.size.height/2 + 300)
        redButton.alpha = 0
        
        blueButton.setScale(0.7)
        blueButton.position = CGPoint(x: self.size.width/2 + 100, y: self.size.height/2 + 300)
        blueButton.alpha = 0
        
        brownButton.setScale(0.7)
        brownButton.position = CGPoint(x: self.size.width/2 - 100, y: self.size.height/2 + 300)
        brownButton.alpha = 0
        
        nextPage.setScale(0.5)
        nextPage.position = CGPoint(x: self.size.width/2, y: self.size.height/2 - 300)
        nextPage.alpha = 0
        
        
        brown.setScale(0.5)
        brown.position = CGPoint(x: self.size.width/2 , y: self.size.height/2 - 155)
        brown.alpha = 0
       
        fullRainbow.setScale(1.8)
        fullRainbow.position = CGPoint(x: self.size.width/2 , y: self.size.height/2 - 130)
        
        chapterII.setScale(0.5)
        chapterII.position = CGPoint(x: self.size.width/2 , y: self.size.height/2)

        
        self.backgroundColor = UIColor(red: 0.91, green: 0.76, blue: 0.61, alpha: 1.00)
        addChild(fullRainbow)
        addChild(brown)
        addChild(redButton)
        addChild(blueButton)
        addChild(brownButton)
        addChild(nextPage)
        addChild(chapterII)
        
        nextPage.zPosition = 10
        
        chapterII.run(.sequence([fadeOutWait,fadeOut]))
        
        let backgroundGroup = SKAction.group([backgroundScale,backgroundMove, backgroundFade])
        
        fullRainbow.run(.sequence([fadeOutWait, backgroundGroup]))
       
        brown.run(.sequence([fadeOutWait,fadeInWait, fadeIn]))
       
        blueButton.run(.sequence([fadeOutWait,fadeInWait, fadeIn]))
        brownButton.run(.sequence([fadeOutWait,fadeInWait, fadeIn]))
        redButton.run(.sequence([fadeOutWait,fadeInWait, fadeIn]))

        
        addChild(nextPage1)
        nextPage1.setScale(0.5)
        nextPage1.position = CGPoint(x: self.size.width/2, y: self.size.height/2 - 300)
        nextPage1.alpha = 0
        
        quote1.text = "why little brown girl did you braid your hair?"
        quote2.text = "it’s because you want to look like the others"
        quote3.text = "or it’s because you want to keep hidden what"
        quote4.text = "makes you different"
        
        quote1.alpha = 0
        quote2.alpha = 0
        quote3.alpha = 0
        quote4.alpha = 0
        
        quote1.fontSize =  20
        quote2.fontSize =  20
        quote3.fontSize =  20
        quote4.fontSize =  20
        
        addChild(quote1)
        addChild(quote2)
        addChild(quote3)
        addChild(quote4)
        
        }
    
    func touchDown(atPoint pos : CGPoint) {
        
        if  redCont == 1  {
            nextPage.run(.sequence([fadeIn]))
        }
        
        if blueButton.contains(pos) {
            brown.texture = SKTexture.init(imageNamed: "blue")
            blueCont += 1
        }
        if redButton.contains(pos) {
            brown.texture = SKTexture.init(imageNamed: "red")
            redCont += 1
        }
        if brownButton.contains(pos) {
            brown.texture = SKTexture.init(imageNamed: "brown")
            brownCont += 1
        }
        if nextPage.contains(pos) {
            brown.run(fadeOut)
            blueButton.run(fadeOut)
            redButton.run(fadeOut)
            brownButton.run(fadeOut)
            
            nextPage.run(fadeOut)
            
            
            let backgroundFade2 = SKAction.fadeAlpha(to: 0.30, duration: 2)
            
            fullRainbow.run(backgroundFade2)
            
            let colorChange = SKAction.colorize(with: #colorLiteral(red: 0.4966557622, green: 0.2754850984, blue: 0.1952499151, alpha: 1), colorBlendFactor: 1, duration: 2)
            
            self.run(colorChange)
            
            quote1.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+200)
            quote1.run(.sequence([fadeInWait, fadeIn]))
            
            quote2.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+150)
            quote2.run(.sequence([fadeInWait, waitText, fadeIn]))
            
            quote3.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+100)
            quote3.run(.sequence([fadeInWait, waitText, waitText, fadeIn]))
            
            quote4.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+50)
            quote4.run(.sequence([fadeInWait, waitText,waitText, fadeInWait, fadeIn]))
            
            
            
            
            nextPage1.run(.sequence([fadeInWait, waitText,waitText,waitText, fadeInWait, fadeIn]))
            
            
        }
        if nextPage1.contains(pos) && nextPage1.alpha == 1{
            PlaygroundPage.current.navigateTo(page: .next)
        }
        
    }

    func touchMoved(toPoint pos : CGPoint) {
    
    }

    func touchUp(atPoint pos : CGPoint) {
        
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func update(_ currentTime: TimeInterval){
        
    }
}



