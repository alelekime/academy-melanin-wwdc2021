//
//  Black.swift
//  BookCore
//
//  Created by Alessandra Souza da Silva on 15/04/21.
//
import SpriteKit
import PlaygroundSupport
import Foundation
public class Black: SKScene {
    
    let chapterIII = SKSpriteNode(imageNamed: "chapter3")
    let nextPage = SKSpriteNode(imageNamed: "nextPage")
    let nextPage1 = SKSpriteNode(imageNamed: "nextChapter")
    let black = SKSpriteNode(imageNamed: "black")
    let noHair = SKSpriteNode(imageNamed: "noHair")
    let fullRainbow = SKSpriteNode(imageNamed: "fullRainbow")
    let comb = SKSpriteNode(imageNamed: "pick")
    var penteSelect = false
    var tam: CGFloat = 0.5
    var max: CGFloat = 0.8
    
    let person = SKNode()
    
    let quote1 = SKLabelNode(fontNamed: "Palatino")
    let quote2 = SKLabelNode(fontNamed: "Palatino")
    let quote3 = SKLabelNode(fontNamed: "Palatino")
    let quote4 = SKLabelNode(fontNamed: "Palatino")
    let quote5 = SKLabelNode(fontNamed: "Palatino")
    
    
    let fadeOutWait = SKAction.wait(forDuration: 4)
    let fadeOut = SKAction.fadeOut(withDuration: 1)
    let fadeIn = SKAction.fadeIn(withDuration: 2)
    let backgroundScale = SKAction.scale(by: 0.5, duration: 1)
    let backgroundMove = SKAction.moveBy(x: 0, y: 10, duration: 1)
    let blackMove = SKAction.moveBy(x: 0, y: 5, duration: 1)
    let backgroundFade = SKAction.fadeAlpha(to: 0.23, duration: 0.7)
    let fadeInWait = SKAction.wait(forDuration: 2)
    let waitText = SKAction.wait(forDuration: 2)
    
    
    override public func didMove(to view: SKView) {

        
        comb.setScale(0.2)
        comb.position = CGPoint(x: self.size.width/2 , y: self.size.height/2 + 250)
        comb.alpha = 0
        comb.zPosition = 20
        
        black.position = CGPoint(x: self.size.width/2 - 50 , y: self.size.height/2 - 155)
        black.setScale(0.5)
        
        black.zPosition = 3
        
        noHair.setScale(0.5)
        noHair.position = CGPoint(x: self.size.width/2 - 50, y: self.size.height/2 - 155)
        
        noHair.zPosition = 4
       
        fullRainbow.setScale(1.8)
        fullRainbow.position = CGPoint(x: self.size.width/2 , y: self.size.height/2 - 130)
        
        chapterIII.setScale(0.5)
        chapterIII.position = CGPoint(x: self.size.width/2 , y: self.size.height/2)

        nextPage.setScale(0.5)
        nextPage.position = CGPoint(x: self.size.width/2, y: self.size.height/2 - 300)
        nextPage.alpha = 0
        
        addChild(nextPage1)
        nextPage1.setScale(0.5)
        nextPage1.position = CGPoint(x: self.size.width/2, y: self.size.height/2 - 300)
        nextPage1.alpha = 0
        
        self.backgroundColor = UIColor(red: 0.91, green: 0.76, blue: 0.61, alpha: 1.00)
        
        addChild(fullRainbow)
       addChild(chapterIII)
        addChild(comb)
        
        person.addChild(black)
        person.addChild(noHair)
        addChild(person)
        person.zPosition = 6
        person.alpha = 0
      
        person.position = CGPoint()
        
        addChild(nextPage)
        
        nextPage.zPosition = 10
        
        chapterIII.run(.sequence([fadeOutWait,fadeOut]))
        
        let backgroundGroup = SKAction.group([backgroundScale,backgroundMove, backgroundFade])
        
        fullRainbow.run(.sequence([fadeOutWait, backgroundGroup]))
        
       
        person.run(.sequence([fadeOutWait,fadeInWait, .fadeIn(withDuration: 1)]))
        
        comb.run(.sequence([fadeOutWait,fadeInWait, fadeIn]))
        
        
        
        quote1.fontSize =  20
        quote2.fontSize =  20
        quote3.fontSize =  20
        quote4.fontSize =  20
        quote5.fontSize =  20
        
        quote1.text = "why little brown girl did you free your hair?"
        quote2.text = "it’s because you understood you don't need"
        quote3.text = "hide any part of yourself"
        quote4.text = "or it’s because you saw you’re a queen and"
        quote5.text = "your hair is the crown"
        quote1.alpha = 0
        quote2.alpha = 0
        quote3.alpha = 0
        quote4.alpha = 0
        quote5.alpha = 0
        
        addChild(quote1)
        addChild(quote2)
        addChild(quote3)
        addChild(quote4)
        addChild(quote5)
        
        }



    
    func touchDown(atPoint pos : CGPoint) {
        if comb.contains(pos){
            penteSelect = true
        }
        else{
            penteSelect = false
        }
        if nextPage.contains(pos) {
            
            black.run(fadeOut)
            noHair.run(fadeOut)
            comb.run(fadeOut)
            nextPage.run(fadeOut)
            
            
            let backgroundFade2 = SKAction.fadeAlpha(to: 0.30, duration: 2)
            
            fullRainbow.run(backgroundFade2)
            
            let colorChange = SKAction.colorize(with: #colorLiteral(red: 0.5572010279, green: 0.3431702852, blue: 0.2575088143, alpha: 1), colorBlendFactor: 0.5, duration: 2)
            
            self.run(colorChange)
           
            
            quote1.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+200)
            quote1.run(.sequence([fadeInWait, fadeIn]))
            
            quote2.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+150)
            quote2.run(.sequence([fadeInWait, waitText, fadeIn]))
            
            quote3.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+100)
            quote3.run(.sequence([fadeInWait, waitText, waitText, fadeIn]))
            
            quote4.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+50)
            quote4.run(.sequence([fadeInWait, waitText,waitText, fadeInWait, fadeIn]))
            
            quote5.position = CGPoint(x: self.size.width/2 , y: self.size.height/2)
            quote5.run(.sequence([fadeInWait, waitText,waitText, waitText, fadeInWait, fadeIn]))
            
            
           
        }
        
    }

    func touchMoved(toPoint pos : CGPoint) {
        
        if penteSelect {
            comb.position = pos
            if black.contains(pos) && tam < max {
                tam += 0.001
                black.setScale(tam)
                if black.position.y > -160 {
                    black.position.y -= 0.2
                    black.position.x -= 0.1
                }
                
            }
        }
        if (penteSelect && nextPage.alpha == 0){
            nextPage.run(fadeIn)
            
        }
    }

    func touchUp(atPoint pos : CGPoint) {
        
    }

    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
}



