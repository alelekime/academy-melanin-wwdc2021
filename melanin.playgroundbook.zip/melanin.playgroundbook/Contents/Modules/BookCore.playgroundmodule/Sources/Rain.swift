//
//  Rain.swift
//  BookCore
//
//  Created by Alessandra Souza da Silva on 15/04/21.
//
import SpriteKit
import PlaygroundSupport
import Foundation
public class Rain: SKScene {
    
    let chapterI = SKSpriteNode(imageNamed: "chapter1")
    let backgraundChapter = SKSpriteNode(imageNamed: "backgroundchapter")
    let nextPage = SKSpriteNode(imageNamed: "nextPage")
    let nextPage1 = SKSpriteNode(imageNamed: "nextChapter")
    
    let rain1 = SKSpriteNode(imageNamed:  "rain1")
    let rain2 = SKSpriteNode(imageNamed: "rain2")
    let rain3 = SKSpriteNode(imageNamed: "rain3")
    
    
    
    
    
    let quote1 = SKLabelNode(fontNamed: "Palatino")
    let quote2 = SKLabelNode(fontNamed: "Palatino")
    let quote3 = SKLabelNode(fontNamed: "Palatino")
    let quote4 = SKLabelNode(fontNamed: "Palatino")
    
    let me = SKSpriteNode(imageNamed: "2014")
    let messy = SKSpriteNode(imageNamed: "messy")
    let rainbow = SKSpriteNode(imageNamed: "rainbow")
    let fullRainbow = SKSpriteNode(imageNamed: "fullRainbow")
    var drops = [SKSpriteNode]()
    var dropsBlur = [SKSpriteNode]()
    var hairColision = SKShapeNode(circleOfRadius: 150)
    var contDrop = 0
    
    
    let fadeOutWait = SKAction.wait(forDuration: 4)
    let fadeOut = SKAction.fadeOut(withDuration: 1)
    let fadeIn = SKAction.fadeIn(withDuration: 2)
    let backgroundScale = SKAction.scale(by: 0.5, duration: 1)
    let backgroundMove = SKAction.moveBy(x: 0, y: 10, duration: 1)
    let backgroundFade = SKAction.fadeAlpha(to: 0.23, duration: 0.7)
    let fadeInWait = SKAction.wait(forDuration: 2)
    let waitText = SKAction.wait(forDuration: 2)

    override public func didMove(to view: SKView) {
        
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -2)
        
        addChild(nextPage)
        nextPage.setScale(0.5)
        nextPage.position = CGPoint(x: self.size.width/2, y: self.size.height/2 - 300)
        nextPage.alpha = 0
      
        rain1.setScale(0.25)
        rain1.position = CGPoint(x: self.size.width/2 - 10 , y: self.size.height/2 - 145)
        rain1.alpha = 0
        
        fullRainbow.setScale(1.8)
        fullRainbow.position = CGPoint(x: self.size.width/2 , y: self.size.height/2 - 130)
        
        chapterI.setScale(0.5)
        chapterI.position = CGPoint(x: self.size.width/2 , y: self.size.height/2)
        hairColision.position = CGPoint(x: self.size.width/2+50, y: self.size.width/2+90)
        hairColision.lineWidth = 0

        addChild(nextPage1)
        nextPage1.setScale(0.5)
        nextPage1.position = CGPoint(x: self.size.width/2, y: self.size.height/2 - 300)
        nextPage1.alpha = 0
        
        
        self.backgroundColor = UIColor(red: 0.91, green: 0.76, blue: 0.61, alpha: 1.00)
        
        
        addChild(fullRainbow)
        addChild(chapterI)
        addChild(rain1)
        addChild(hairColision)
        chapterI.run(.sequence([fadeOutWait,fadeOut]))
        let backgroundGroup = SKAction.group([backgroundScale,backgroundMove, backgroundFade])
        fullRainbow.run(.sequence([fadeOutWait, backgroundGroup]))
        
        nextPage.zPosition = 10
        
       
        rain1.run(.sequence([fadeOutWait,fadeInWait, fadeIn])){
            for _ in 0...30 {
                self.createDrop()
            }
            for _ in 0...300{
                self.createDropBlur()
                
            }
        }
        
        quote1.text = "why little brown girl did you straight your hair?"
        quote2.text = "it’s because you don't like yours curly's"
        quote3.text = "it’s because when you go inside a room full of people "
        quote4.text = "you're the only one there"
        
        quote1.alpha = 0
        quote2.alpha = 0
        quote3.alpha = 0
        quote4.alpha = 0
        
        quote1.color = #colorLiteral(red: 0.9098039216, green: 0.7607843137, blue: 0.6117647059, alpha: 1)
        quote2.color = #colorLiteral(red: 0.9098039216, green: 0.7607843137, blue: 0.6117647059, alpha: 1)
        quote3.color = #colorLiteral(red: 0.9098039216, green: 0.7607843137, blue: 0.6117647059, alpha: 1)
        quote4.color = #colorLiteral(red: 0.9098039216, green: 0.7607843137, blue: 0.6117647059, alpha: 1)
        
        quote1.fontSize =  20
        quote2.fontSize =  20
        quote3.fontSize =  20
        quote4.fontSize =  20
        
        addChild(quote1)
        addChild(quote2)
        addChild(quote3)
        addChild(quote4)
        
        
    }
    
    
    
    func touchDown(atPoint pos : CGPoint) {
        for drop in drops {
            if drop.contains(pos) {
                drop.position.y += self.size.height + 100
            }
        }
        if nextPage.contains(pos) && nextPage.alpha == 1{
            
            rain1.run(fadeOut)
            nextPage.run(fadeOut)
            
            
            for drop in dropsBlur {
                drop.run(fadeOut)
            }
            for drop in drops{
                drop.run(fadeOut)
            }
            
            let backgroundFade2 = SKAction.fadeAlpha(to: 0.30, duration: 2)
            
            fullRainbow.run(backgroundFade2)
            
            let colorChange = SKAction.colorize(with: #colorLiteral(red: 0.5572010279, green: 0.3431702852, blue: 0.2575088143, alpha: 1), colorBlendFactor: 0.5, duration: 2)
            
            self.run(colorChange)
            
           
            
            
            quote1.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+160)
            quote1.run(.sequence([fadeInWait, fadeIn]))
            
            quote2.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+120)
            quote2.run(.sequence([fadeInWait, waitText, fadeIn]))
            
            quote3.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+80)
            quote3.run(.sequence([fadeInWait, waitText, waitText, fadeIn]))
            
            quote4.position = CGPoint(x: self.size.width/2 , y: self.size.height/2+40)
            quote4.run(.sequence([fadeInWait, waitText,waitText, fadeInWait, fadeIn]))
            

           
            
            nextPage1.run(.sequence([fadeInWait, waitText,waitText,waitText, fadeInWait, fadeIn]))
            
            
        }
        
        if nextPage1.contains(pos) && nextPage1.alpha == 1{
            PlaygroundPage.current.navigateTo(page: .next)
        }
    }

    func touchMoved(toPoint pos : CGPoint) {
        
    }

    func touchUp(atPoint pos : CGPoint) {
        
    }
    
    func createDrop() {
        let posX = CGFloat.random(in: 0...self.size.width)
        let posY = CGFloat.random(in: self.size.height...self.size.height * 4)
        
        let drop = SKSpriteNode(imageNamed: "drop")
        addChild(drop)
        drop.setScale(0.8)
        drop.position = CGPoint(x: posX, y: posY)
        
        let body = SKPhysicsBody(circleOfRadius: 5)
        body.mass = 0.01
        body.linearDamping = 2
        drop.physicsBody = body
        
        drops.append(drop)
        
        
    }
    func createDropBlur() {
        let posX = CGFloat.random(in: 0...self.size.width)
        let posY = CGFloat.random(in: self.size.height...self.size.height * 4)
        let posZ = CGFloat.random(in: 1...10)
        let drop = SKSpriteNode(imageNamed: "drop")
        addChild(drop)
        drop.setScale(0.6 * (posZ/10))
        drop.position = CGPoint(x: posX, y: posY)
        drop.zPosition = -20 + posZ
        drop.alpha = posZ/15
        
        
        
        dropsBlur.append(drop)
        
        
    }

    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func update(_ currentTime: TimeInterval) {
        for drop in drops{
            
            if drop.position.y < -50 {
                let posX = CGFloat.random(in: 0...self.size.width)
                drop.position.y += self.size.height + 100
                drop.position.x = posX
            }
            if hairColision.contains(drop.position) {
                contDrop += 1
                drop.position.y += self.size.height + 100
                let posX = CGFloat.random(in: 0...self.size.width)
                drop.position.x = posX
                if contDrop == 5 {
                   rain1.texture = SKTexture(imageNamed: "rain2")
                }else if contDrop == 15 {
                    rain1.texture = SKTexture(imageNamed: "rain3")
                    nextPage.run(.sequence([fadeOutWait,fadeIn]))
                }
            }
        }
        for drop in dropsBlur{
            let vel = drop.xScale * 2
            let posX = CGFloat.random(in: 0...self.size.width)
            drop.position.y -= vel
            if drop.position.y < -50 {
                drop.position.y += self.size.height + 100
                drop.position.x = posX
            }
            
        }
        
    }
}
