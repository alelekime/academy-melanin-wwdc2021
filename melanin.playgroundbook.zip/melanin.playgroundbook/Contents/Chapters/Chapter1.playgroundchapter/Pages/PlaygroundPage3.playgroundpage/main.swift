/*:
 
 # Braiding Hair
 
 The art of Braiding Hair come from the roots on Africa, is possible to do with you own hair or with colorful hair extensions. It's beautiful either way



* Experiment: Try to click on colorful buttons on the top. You see the colors appear.

*/


//#-hidden-code

import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
let scene = Colors(size: CGSize(width: 512, height: 768))
scene.scaleMode = .aspectFit
sceneView.presentScene(scene)

PlaygroundPage.current.wantsFullScreenLiveView = false
PlaygroundPage.current.liveView = sceneView
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
