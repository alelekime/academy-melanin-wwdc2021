/*:
 
 # Straight hair and Hair Relaxer
 
 The hair relaxer and the hot comb temporarily straightened out curly and kinky textures. The big **PROBLEM** with using the hot Combs is: if even a little drop of water get to hair, everthing start to cramble

* Experiment: Try to click on the water droplets before they get to the hair. If that happens, then you see the hair change.

*/


//#-hidden-code
import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
let scene = Rain(size: CGSize(width: 512, height: 768))
scene.scaleMode = .aspectFit
sceneView.presentScene(scene)

PlaygroundPage.current.wantsFullScreenLiveView = false
PlaygroundPage.current.liveView = sceneView
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code

