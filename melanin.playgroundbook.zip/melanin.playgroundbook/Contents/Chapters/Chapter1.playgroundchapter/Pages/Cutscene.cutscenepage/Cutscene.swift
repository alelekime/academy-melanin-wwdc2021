
//#-hidden-code
/*:
 # Título principal!
 
 Um demo *simples* com exemplos de *markup*.
 
 Algo muito importante em **negrito** chama muita **atenção**
 
 
 ## Isso é um subtítulo nível 2
 ### Isso é um subtítulo nível 3

 
 Você pode fazer uma linha para dividir seções
 
 ---
 
 - Note: Uma nota legal que aparece assim
 
 - Experiment: Experimente trocar a velocidade do bonequinho para ver o que acontece!!
 
 ## Bullet Points
* Ponto importante 1
* Ponto ❤️
* Cuidado com as 🕷🕷🕷 **aranhas**
 
1) Numerados
1) Numerados
 
 
 Você pode usar [links](http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/) com referências
 
 */

/*:

 ![Uma imagem explicativa](fractal@2x.png)
 
 */


//#-hidden-code


import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 1024, height: 768))
let scene = GameScene(size: CGSize(width: 1024, height: 768))
scene.scaleMode = .aspectFit
sceneView.presentScene(scene)

PlaygroundPage.current.liveView = sceneView
PlaygroundPage.current.needsIndefiniteExecution = true
